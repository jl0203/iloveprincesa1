# Amor Eterno — Versão com Fotos Embutidas (Base64)

Esta versão já vem com as fotos **embutidas no código** usando Base64.
- Você NÃO precisa enviar imagens ao GitHub; basta subir esses arquivos.
- A galeria (`galeria.html`) carrega as fotos a partir do `assets/js/app.js`.

## Publicar no GitHub Pages
1. Crie um repositório (ex.: `amor-eterno-embutido`), público.
2. Envie os arquivos desta pasta para a raiz do repositório.
3. Vá em **Settings → Pages** → *Build and deployment*:
   - **Source:** Deploy from a branch
   - **Branch:** `main` e `/ (root)`
4. Acesse a URL `https://SEU-USUARIO.github.io/amor-eterno-embutido/`.
